=== WPGraphQL for Rank Math ===
Contributors: axepress, justlevine
Tags: GraphQL, Gatsby, Headless, WPGraphQL, React, Rest, RankMath, Seo, Schema
Requires at least: 6.0
Tested up to: 6.3.2
Requires PHP: 7.4
Requires WPGraphQL: 1.14.0
Stable tag: 0.0.16
License: GPL-3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

== Description ==
== Upgrade Notice ==
== Frequently Asked Questions ==
== Screenshots ==
== Changelog ==
<a href="https://github.com/AxeWP/wp-graphql-rank-math/blob/main/CHANGELOG.md>Click here for full changelog.</a>
