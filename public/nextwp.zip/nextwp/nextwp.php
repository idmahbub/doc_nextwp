<?php
/**
 * Classic Editor
 *
 * Plugin Name: NextWp Magazine Headless Wordpress
 * Plugin URI: https://wicsolution.com/
 * Description: Make wordpress site with modern stacks.
 * Author: idmahbub
 * Version: 1.0
 * Author URI: https://mahbub.wicsolution.com/
 * Text Domain: nextwp
 * Domain Path: /languages
 * Requires at least: 4.9
 * Requires PHP: 5.2.4
 *
 */
add_action('admin_menu', 'nextwp_menu');
/* What to do when the plugin is activated? */
register_activation_hook(__FILE__, 'nextwp_install');
/* What to do when the plugin is deactivated? */
register_deactivation_hook(__FILE__, 'nextwp_uninstall');


// Khi install thi khoi tao cac gia tri ban dau
function nextwp_install()
{
    function randomSalt($len = 64) {
        $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789`~!@#$%^&*()-=_+';
        $l = strlen($chars) - 1;
        $str = '';
        for ($i = 0; $i < $len; ++$i) {
            $str .= $chars[rand(0, $l)];
         }
        return $str;
    }
    if (!defined('GRAPHQL_JWT_AUTH_SECRET_KEY')){
            $current_wp_config = file_get_contents(ABSPATH . 'wp-config.php');
            $my_defines = "/* First we put WP_ALLOW_MULTISITE  */\r\n" .
                    "define('GRAPHQL_JWT_AUTH_SECRET_KEY', '".randomSalt()."'); \r\n";
            $current_wp_config = str_replace("/* That's all, stop editing", $my_defines . "/* That's all, stop editing", $current_wp_config);       
            file_put_contents(ABSPATH . 'wp-config.php', $current_wp_config);   
    }
    add_option('GOOGLE_CSE', '1234');
    add_option('LATE_POST_TITLE', 'Lates Posts');
    add_option('LATE_POST_DESC', 'Great News and Article for more knowledge');
    add_option('PRIMARY_MENU', '');
    add_option('FOOTER_MENU', '');
    add_option('PUBLIC_GOOGLE_ADS_CLIENT_ID', '');
    add_option('ADS_SLOT_1', '');
    add_option('ADS_SLOT_2', '');
    add_option('ADS_SLOT_3', '');
    add_option('ADS_SLOT_4', '');
    add_option('ADS_SLOT_5', '');
    add_option('INLINE_ADS_EVERY', ''); 
    
}

//Khi xoa thi delete...
function nextwp_uninstall()
{
    global $wpdb;

    delete_option('GOOGLE_CSE');
    delete_option('LATE_POST_TITLE');
    delete_option('LATE_POST_DESC');
    delete_option('PRIMARY_MENU');
    delete_option('FOOTER_MENU');
    delete_option('PUBLIC_GOOGLE_ADS_CLIENT_ID');
    delete_option('ADS_SLOT_1');
    delete_option('ADS_SLOT_2');
    delete_option('ADS_SLOT_3');
    delete_option('ADS_SLOT_4');
    delete_option('ADS_SLOT_5');
    delete_option('INLINE_ADS_EVERY');
    delete_option('GRAPHQL_JWT_AUTH_SECRET_KEY');
}

require_once 'src/core.php';

function nextwp_menu()
{
    add_options_page('NextWp', 'NextWp', 'manage_options', basename(__FILE__), 'nextwp_setting');
}
function nextwp_setting()
{
    global $wpdb, $post;
    if (isset($_POST['submit_setting'])) {
        if (get_option('GOOGLE_CSE') !== false) {
            update_option('GOOGLE_CSE', (($_POST['GOOGLE_CSE'])));
        } else {
            add_option('GOOGLE_CSE', (($_POST['GOOGLE_CSE'])));
        }
        if (get_option('LATE_POST_TITLE') !== false) {
            update_option('LATE_POST_TITLE', (($_POST['LATE_POST_TITLE'])));
        } else {
            add_option('LATE_POST_TITLE', (($_POST['LATE_POST_TITLE'])));
        }
        if (get_option('LATE_POST_DESC') !== false) {
            update_option('LATE_POST_DESC', (($_POST['LATE_POST_DESC'])));
        } else {
            add_option('LATE_POST_DESC', (($_POST['LATE_POST_DESC'])));
        }
        if (get_option('PRIMARY_MENU') !== false) {
            update_option('PRIMARY_MENU', (($_POST['PRIMARY_MENU'])));
        } else {
            add_option('PRIMARY_MENU', (($_POST['PRIMARY_MENU'])));
        }
        if (get_option('FOOTER_MENU') !== false) {
            update_option('FOOTER_MENU', (($_POST['FOOTER_MENU'])));
        } else {
            add_option('FOOTER_MENU', (($_POST['FOOTER_MENU'])));
        }
        if (get_option('PUBLIC_GOOGLE_ADS_CLIENT_ID') !== false) {
            update_option('PUBLIC_GOOGLE_ADS_CLIENT_ID', (($_POST['PUBLIC_GOOGLE_ADS_CLIENT_ID'])));
        } else {
            add_option('PUBLIC_GOOGLE_ADS_CLIENT_ID', (($_POST['PUBLIC_GOOGLE_ADS_CLIENT_ID'])));
        }
        if (get_option('ADS_SLOT_1') !== false) {
            update_option('ADS_SLOT_1', (($_POST['ADS_SLOT_1'])));
        } else {
            add_option('ADS_SLOT_1', (($_POST['ADS_SLOT_1'])));
        }
        if (get_option('ADS_SLOT_2') !== false) {
            update_option('ADS_SLOT_2', (($_POST['ADS_SLOT_2'])));
        } else {
            add_option('ADS_SLOT_2', (($_POST['ADS_SLOT_2'])));
        }
        if (get_option('ADS_SLOT_3') !== false) {
            update_option('ADS_SLOT_3', (($_POST['ADS_SLOT_3'])));
        } else {
            add_option('ADS_SLOT_3', (($_POST['ADS_SLOT_3'])));
        }
        if (get_option('ADS_SLOT_4') !== false) {
            update_option('ADS_SLOT_4', (($_POST['ADS_SLOT_4'])));
        } else {
            add_option('ADS_SLOT_4', (($_POST['ADS_SLOT_4'])));
        }
        if (get_option('ADS_SLOT_5') !== false) {
            update_option('ADS_SLOT_5', (($_POST['ADS_SLOT_5'])));
        } else {
            add_option('ADS_SLOT_5', (($_POST['ADS_SLOT_5'])));
        }
        if (get_option('INLINE_ADS_EVERY') !== false) {
            update_option('INLINE_ADS_EVERY', (($_POST['INLINE_ADS_EVERY'])));
        } else {
            add_option('INLINE_ADS_EVERY', (($_POST['INLINE_ADS_EVERY'])));
        }
        
    }
    
    ?>
    <h1>NextWp  Magazine Headless Wordpress</h1>
		<div class="elita-kkrating-container">
			<div class="elita-kkrating-left">
                <?php 
                    $all_plugins = get_option('active_plugins');
                    
                    if(!in_array('wp-graphql/wp-graphql.php',$all_plugins)) { 
                        echo '<a target="_blank" href="https://wordpress.org/plugins/wp-graphql/" class="button button-primary">! Need WPGraphQL Plugin</a><br />';
                    }
                    if(!in_array('wp-graphql-jwt-authentication-0.7.0/wp-graphql-jwt-authentication.php',$all_plugins)) {
                        echo '<a target="_blank" href="https://github.com/wp-graphql/wp-graphql-jwt-authentication/archive/refs/tags/v0.7.0.zip" class="button button-primary">! Need WPGraphQL JWT Authentication Plugin</a><br />';
                    }
                    if(!in_array( 'seo-by-rank-math/rank-math.php', $all_plugins ) ){
                        echo '<a target="_blank" href="https://wordpress.org/plugins/seo-by-rank-math/" class="button button-primary">! Need Rank Math SEO with AI SEO Tools Plugin</a><br />';
                    }
                    if(!in_array('wp-graphql-rank-math-0.0.16/wp-graphql-rank-math.php',$all_plugins)) {
                        echo '<a target="_blank" href="https://github.com/AxeWP/wp-graphql-rank-math/archive/refs/tags/0.0.16.zip" class="button button-primary">! Need WPGraphQL for Rank Math SEO Plugin</a><br />';
                    }
                ?>
            <p><strong>After successfully installing and activating the all required plugins, you need to set the env file in the nextjs application project, back to documentations for details. </strong> </p>
                <!--
            <form method="post" id="elita_exchange_setting">
                <table class="form-table">
					<tbody>
			        	<tr valign="top">
							<th  scope="row" width="150">GOOGLE_CSE</th>
							<td scope="row">
								<input type="text"  style="width:100%;" name="GOOGLE_CSE" value="<?php echo get_option('GOOGLE_CSE'); ?>" />
								<p class="description">GOOGLE_CSE is the ID code from the Google custom search engine, we use this to display site search results, you can see the full details <a href="https://help.elfsight.com/article/331-how-to-get-search-engine-id">here</a>.</p>
							</td>
						</tr>

						<tr valign="top">
							<th  scope="row">LATE_POST_TITLE</th>
							<td scope="row">
								<input type="text"   step="any" style="width:100%;" name="LATE_POST_TITLE" value="<?php echo get_option('LATE_POST_TITLE'); ?>" />
								<p class="description">Label for the latest posts area, default[ Lates Post ] </p>
							</td>
						</tr>

                        <tr valign="top">
							<th  scope="row">LATE_POST_DESC</th>
							<td scope="row">
                                <textarea name="LATE_POST_DESC" style="width:100%;"><?php echo get_option('LATE_POST_DESC'); ?></textarea>
								<p class="description">Description for lates post area default[ Great News and Article for more knowledge ] </p>
							</td>
						</tr>

                        <tr valign="top">
							<th  scope="row">PRIMARY_MENU</th>
							<td scope="row">
								<input type="text"   step="any" style="width:100%;" name="PRIMARY_MENU" value="<?php echo get_option('PRIMARY_MENU'); ?>" />
								<p class="description">Token JWT for securing front end communication </p>
							</td>
						</tr>

                        <tr valign="top">
							<th  scope="row">FOOTER_MENU</th>
							<td scope="row">
								<input type="text"   step="any" style="width:100%;" name="FOOTER_MENU" value="<?php echo get_option('FOOTER_MENU'); ?>" />
								<p class="description">Token JWT for securing front end communication </p>
							</td>
						</tr>

                        <tr valign="top">
							<th  scope="row">PUBLIC_GOOGLE_ADS_CLIENT_ID</th>
							<td scope="row">
								<input type="text"   step="any" style="width:100%;" name="PUBLIC_GOOGLE_ADS_CLIENT_ID" value="<?php echo get_option('PUBLIC_GOOGLE_ADS_CLIENT_ID'); ?>" />
								<p class="description">Adsense <a href="https://support.google.com/adsense/answer/105516?hl=en">Pub ID</a> </p>
							</td>
						</tr>

                        <tr valign="top">
							<th  scope="row">ADS_SLOT_1</th>
							<td scope="row">
								<input type="number"   step="any" style="width:100%;" name="ADS_SLOT_1" value="<?php echo get_option('ADS_SLOT_1'); ?>" />
								<p class="description">Adsense ads slot (Ad Unit), for header responsive. About of adsense ad unit click <a href="https://support.google.com/adsense/answer/9183549?hl=en&sjid=10204627693306661875-AP">here</a>. </p>
							</td>
						</tr>

                        <tr valign="top">
							<th  scope="row">ADS_SLOT_2</th>
							<td scope="row">
								<input type="number"   step="any" style="width:100%;" name="ADS_SLOT_2" value="<?php echo get_option('ADS_SLOT_2'); ?>" />
								<p class="description">Adsense ads slot (Ad Unit), for sidebar desktop. About of adsense ad unit click <a href="https://support.google.com/adsense/answer/9183549?hl=en&sjid=10204627693306661875-AP">here</a>. </p>
							</td>
						</tr>

                        <tr valign="top">
							<th  scope="row">ADS_SLOT_3</th>
							<td scope="row">
								<input type="number"   step="any" style="width:100%;" name="ADS_SLOT_3" value="<?php echo get_option('ADS_SLOT_3'); ?>" />
								<p class="description">Adsense ads slot (Ad Unit), for sidebar desktop sticky. About of adsense ad unit click <a href="https://support.google.com/adsense/answer/9183549?hl=en&sjid=10204627693306661875-AP">here</a>. </p>
							</td>
						</tr>

                        <tr valign="top">
							<th  scope="row">ADS_SLOT_4</th>
							<td scope="row">
								<input type="number"   step="any" style="width:100%;" name="ADS_SLOT_4" value="<?php echo get_option('ADS_SLOT_4'); ?>" />
								<p class="description">Adsense ads slot (Ad Unit), for sidebar under Table Of Content Desktop. About of adsense ad unit click <a href="https://support.google.com/adsense/answer/9183549?hl=en&sjid=10204627693306661875-AP">here</a>. </p>
							</td>
						</tr>

                        <tr valign="top">
							<th  scope="row">ADS_SLOT_5</th>
							<td scope="row">
								<input type="number"   step="any" style="width:100%;" name="ADS_SLOT_5" value="<?php echo get_option('ADS_SLOT_5'); ?>" />
								<p class="description">Adsense ads slot (Ad Unit), for inline content responsive. About of adsense ad unit click <a href="https://support.google.com/adsense/answer/9183549?hl=en&sjid=10204627693306661875-AP">here</a>. </p>
							</td>
						</tr>

                        <tr valign="top">
							<th  scope="row">INLINE_ADS_EVERY</th>
							<td scope="row">
								<input type="number"   step="any" style="width:100%;" name="INLINE_ADS_EVERY" value="<?php echo get_option('INLINE_ADS_EVERY'); ?>" />
								<p class="description">Advertisements in articles will be displayed every how many paragraphs? default[5] </p>
							</td>
						</tr>

			            <tr valign="top">
							<th  scope="row"></th>
							<td scope="row">
								<p class="submit"><input type="submit" name="submit_setting" id="submit" class="button button-primary" value="Apply Settings"></p>
							</td>
						</tr>
					</tbody>
                </table>
                </form>
                
                <ul>
                
                <li class="description">GOOGLE_CSE = is the ID code from the Google custom search engine, we use this to display site search results, you can see the full details <a href="https://help.elfsight.com/article/331-how-to-get-search-engine-id">here</a>.</li>
                <li class="description">LATE_POST_TITLE = Label for the latest posts area, default[ Lates Post ] </li>
                <li class="description">LATE_POST_DESC = Description for lates post area default[ Great News and Article for more knowledge ] </li>
                <li class="description">JWT_AUTH_REFRESH_TOKEN = Token JWT for securing front end communication </li>
                <li class="description">PUBLIC_GOOGLE_ADS_CLIENT_ID = Adsense <a href="https://support.google.com/adsense/answer/105516?hl=en">Pub ID</a> </li>
                <li class="description">ADS_SLOT_1 = Adsense ads slot (Ad Unit), for header responsive. About of adsense ad unit click <a href="https://support.google.com/adsense/answer/9183549?hl=en&sjid=10204627693306661875-AP">here</a>. </li>
                <li class="description">ADS_SLOT_2 = Adsense ads slot (Ad Unit), for sidebar desktop. About of adsense ad unit click <a href="https://support.google.com/adsense/answer/9183549?hl=en&sjid=10204627693306661875-AP">here</a>. </li>
                <li class="description">ADS_SLOT_3 = Adsense ads slot (Ad Unit), for sidebar desktop sticky. About of adsense ad unit click <a href="https://support.google.com/adsense/answer/9183549?hl=en&sjid=10204627693306661875-AP">here</a>. </li>
                <li class="description">ADS_SLOT_4 = Adsense ads slot (Ad Unit), for sidebar under Table Of Content Desktop. About of adsense ad unit click <a href="https://support.google.com/adsense/answer/9183549?hl=en&sjid=10204627693306661875-AP">here</a>. </li>
                <li class="description">ADS_SLOT_5 = Adsense ads slot (Ad Unit), for inline content responsive. About of adsense ad unit click <a href="https://support.google.com/adsense/answer/9183549?hl=en&sjid=10204627693306661875-AP">here</a>. </li>
                <li class="description">INLINE_ADS_EVERY = Advertisements in articles will be displayed every how many paragraphs? default[5] </li>
                </ul>-->
			</div>
			<div class="elita-kkrating-right">
				<a href="https://mahbub.wicsolution.com/?utm_source=<?php echo urlencode(home_url()); ?>&utm_medium=plugin-adjust-kkrating&utm_campaign=plugins" target="_blank" class="btn-donate">Buy me Coffe</a>
			</div>
			<div class="clearfix"></div>
		</div>
        
    <?php
}
add_action('admin_enqueue_scripts', 'nextwp_script');
function nextwp_script($hook)
{
    if ($hook == 'settings_page_nextwp') {
        wp_enqueue_script('jquery');
        wp_enqueue_style('nextwp.css', plugin_dir_url(__FILE__) . 'nextwp.css');

    }
}
?>