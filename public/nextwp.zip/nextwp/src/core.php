<?php

//cleaning content
function cleaning_content ( $content ) {
    if ( is_single() ) {
        $content = html_entity_decode($content);
        $content = preg_replace('#<br[^>]*?>#siu', "\n", $content);
        $content = preg_replace(
            [
                '#<head[^>]*?>.*?</head>#siu',
                '#<style[^>]*?>.*?</style>#siu'
            ],
            '',$content
        );
        // Trim whitespace
        $content = str_replace("noscript", 'div', $content);
        $content = preg_replace('#\n\r|\r\n#', "\n", $content);
        $content = preg_replace('#\n{3,}#', "\n\n", $content);
        $content = trim($content);
        return $content;
    }

    return $content;
}
add_filter( 'the_content', 'cleaning_content');
//remove style from single post
add_filter('the_content', function ($content) {
    if (is_singular('post')) {
        return str_replace(' style="', ' data-style="', $content);
    } else {
        return $content;
    }
});
/*graphql*/
//filter as view
add_filter('graphql_PostObjectsConnectionOrderbyEnum_values', function ($values) {
    $values['nextwp_views_count'] = [
        'value' => 'nextwp_views_count',
        'description' => __('The number of views on the post', 'Count of Views'),
    ];
    $values['nextwp_rating_count'] = [
        'value' => 'nextwp_rating_count',
        'description' => __('The number of _kksr_avg', 'Count of _kksr_avg'),
    ];
    $values['nextwp_rating_avg'] = [
        'value' => 'nextwp_rating_avg',
        'description' => __('The number of _kksr_avg', 'Count of _kksr_avg'),
    ];
    return $values;
});
add_filter('graphql_post_object_connection_query_args', function ($query_args, $source, $input) {
    if (isset($input['where']['orderby']) && is_array($input['where']['orderby'])) {
        foreach ($input['where']['orderby'] as $orderby) {
            if (!isset($orderby['field']) || 'nextwp_views_count' !== $orderby['field']) {
                continue;
            }
            $query_args['meta_key'] = 'nextwp_views_count';
            $query_args['orderby'] = 'meta_value_num';
            $query_args['order'] = $orderby['order'];
        }
    }
    return $query_args;
}, 10, 3);
add_filter('graphql_post_object_connection_query_args', function ($query_args, $source, $input) {
    if (isset($input['where']['orderby']) && is_array($input['where']['orderby'])) {
        foreach ($input['where']['orderby'] as $orderby) {
            if (!isset($orderby['field']) || 'nextwp_rating_count' !== $orderby['field']) {
                continue;
            }
            $query_args['meta_key'] = 'nextwp_rating_count';
            $query_args['orderby'] = 'meta_value_num';
            $query_args['order'] = $orderby['order'];
        }
    }
    return $query_args;
}, 10, 3);
add_filter('graphql_post_object_connection_query_args', function ($query_args, $source, $input) {
    if (isset($input['where']['orderby']) && is_array($input['where']['orderby'])) {
        foreach ($input['where']['orderby'] as $orderby) {
            if (!isset($orderby['field']) || 'nextwp_rating_avg' !== $orderby['field']) {
                continue;
            }
            $query_args['meta_key'] = 'nextwp_rating_avg';
            $query_args['orderby'] = 'meta_value_num';
            $query_args['order'] = $orderby['order'];
        }
    }
    return $query_args;
}, 10, 3);
//input update mutation
add_action('graphql_input_fields', function ($fields, $type_name, $config) {
    if ($type_name === 'CreatePostInput' || $type_name === 'UpdatePostInput') {
        $fields = array_merge($fields, [
            'nextwp_views_count' => ['type' => 'Int'],
            'nextwp_rating_count' => ['type' => 'Int'],
            'nextwp_rating_avg' => ['type' => 'Int'],
        ]);
    }
    return $fields;
}, 20, 3);
add_action('graphql_post_object_mutation_update_additional_data', function ($post_id, $input, $mutation_name, $context, $info) {
    if (!empty($input['nextwp_views_count'])) {
        update_post_meta($post_id, 'nextwp_views_count', $input['nextwp_views_count']);
    }
    if (!empty($input['nextwp_rating_count'])) {
        update_post_meta($post_id, 'nextwp_rating_count', $input['nextwp_rating_count']);
    }
    if (!empty($input['nextwp_rating_avg'])) {
        update_post_meta($post_id, 'nextwp_rating_avg', $input['nextwp_rating_avg']);
    }
}, 10, 5);
//register to get data fields
add_action('graphql_register_types', 'register_nextwp_type');
function register_nextwp_type()
{
    register_graphql_object_type('NextWp', [
        'description' => __("NextWp Post Meta", 'NextWp'),
        'fields' => [
            'nextwp_views_count' => [
                'type' => 'Int',
                'description' => __('The NextWp', 'NextWp'),
            ],
            'nextwp_rating_count' => [
                'type' => 'Int',
                'description' => __('The NextWp', 'NextWp'),
            ],
            'nextwp_rating_avg' => [
                'type' => 'Int',
                'description' => __('The NextWp', 'NextWp'),
            ],
            'nextwp_option' => ['type' => 'String', 'description' => __('The NextWp', 'NextWp')],

        ],
    ]);
}

add_action('graphql_register_types', 'register_NextWp_field');
function register_NextWp_field()
{
    register_graphql_field('RootQuery', 'nextwp_option', [
        'type' => 'String',
        'description' => __('Next Wp Option', 'wp-graphql'),
        'resolve' => function ($root) {
            $nextwp_option = array();
            $nextwp_option['GOOGLE_CSE'] = get_option('GOOGLE_CSE');
            $nextwp_option['LATE_POST_TITLE'] = get_option('LATE_POST_TITLE');
            $nextwp_option['LATE_POST_DESC'] = get_option('LATE_POST_DESC');
            $nextwp_option['PRIMARY_MENU'] = get_option('PRIMARY_MENU');
            $nextwp_option['FOOTER_MENU'] = get_option('FOOTER_MENU');
            $nextwp_option['PUBLIC_GOOGLE_ADS_CLIENT_ID'] = get_option('PUBLIC_GOOGLE_ADS_CLIENT_ID');
            $nextwp_option['ADS_SLOT_1'] = get_option('ADS_SLOT_1');
            $nextwp_option['ADS_SLOT_2'] = get_option('ADS_SLOT_2');
            $nextwp_option['ADS_SLOT_3'] = get_option('ADS_SLOT_3');
            $nextwp_option['ADS_SLOT_4'] = get_option('ADS_SLOT_4');
            $nextwp_option['ADS_SLOT_5'] = get_option('ADS_SLOT_5');
            $nextwp_option['INLINE_ADS_EVERY'] = get_option('INLINE_ADS_EVERY');
            return json_encode($nextwp_option);
        },
    ]);

    register_graphql_field('Post', 'nextwp_views_count', [
        'type' => 'String',
        'description' => __('My test field', 'wp-graphql'),
        'resolve' => function ($post) {
            $metad = get_post_meta($post->ID, 'nextwp_views_count', true);
            if (empty($metad)) {
                update_post_meta($post->ID, 'nextwp_views_count', 1, true);
            }
            return $metad;
        },
    ]);
    register_graphql_field('Post', 'nextwp_rating_count', [
        'type' => 'String',
        'description' => __('My test field', 'wp-graphql'),
        'resolve' => function ($post) {
            $metad = get_post_meta($post->ID, 'nextwp_rating_count', true);
            if (empty($metad)) {
                update_post_meta($post->ID, 'nextwp_rating_count', 0, true);
            }
            return $metad;
        },
    ]);
    register_graphql_field('Post', 'nextwp_rating_avg', [
        'type' => 'String',
        'description' => __('My test field', 'wp-graphql'),
        'resolve' => function ($post) {
            $metad = get_post_meta($post->ID, 'nextwp_rating_avg', true);
            if (empty($metad)) {
                update_post_meta($post->ID, 'nextwp_rating_avg', 0, true);
            }
            return $metad;
        },
    ]);
}
