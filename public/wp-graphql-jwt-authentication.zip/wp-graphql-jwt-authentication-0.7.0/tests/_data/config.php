define( 'GRAPHQL_JWT_AUTH_SECRET_KEY', 'test-token' );
define( 'GRAPHQL_DEBUG', true );
define( 'WPGRAPHQL_AUTOLOAD', false );
define( 'WP_AUTO_UPDATE_CORE', false );
define( 'AUTOMATIC_UPDATER_DISABLED', true );
